function [rankMat,rankedG] = rankp(P)

%--------------------------------------------------------------------------
%DESCRIPTION:
%           The function for DeltaNeTS for generating rank matrix and
%           ranked gene lists.
%INPUT ARGUMENTS:
% P             The P matrix of DeltaNeTS output.
%OUTPUT ARGUMENTS:
% rankMat       The matrix of gene ranks. The rows correspond to the
%               genes as the same order as GList, and the columns 
%               correspond to samples. The smaller rank values, the greater
%               (absolute) magnitudes in perturbation estimates in each 
%               column of P.
% rankedG       The matrix of ranked genes. The rows correspond to rank 1
%               to n, and the columns correspond to samples. The genes were
%               ranked based on (absolute) perturbation magnitudes in each 
%               column of P.
%--------------------------------------------------------------------------

[sortval1,sorti]=sort(abs(P),'descend');
[sortval2,rankMat] =  sort(sorti);
[n,m] = size(P);
rankMat(P==0)=n;

rankedG = {};
for j= 1:m
rankedG = [rankedG,GList(sorti(:,j))];
end