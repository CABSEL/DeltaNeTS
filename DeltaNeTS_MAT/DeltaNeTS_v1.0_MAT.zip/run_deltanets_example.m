%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% An example script to run DeltaNeTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% 1. Set working directory to 'DeltaNeTS_MAT'
%%% e.g. cd('your_path/DeltaNeTS_MAT')

%%% 2. Import example data from the folder 'example_data'
filepath = '.\';% filepath = 'set the current file path', note: '\'for window and '/' for Mac and Linux in defining a path;
datapath = strcat(filepath,'example_data\');

lfc = dlmread(strcat(datapath,'log2FC_GNW1_114KO-EXP_6tpooints.txt'),'\t');
tobject = readtable(strcat(datapath,'table_of_samples.txt'),'delimiter','\t');
tp = tobject.Time;
grplist = tobject.Group;
GList = readtable(strcat(datapath,'GList.txt'),'ReadVariableNames',false);
GList = GList.Var1;

%%% 3.Calculate slopes of log2FC for each time point
slope = generateSlope(lfc,tp,grplist);

%% DeltaNeTS implementation with parallel computing 
% To run DeltaNeTS, glmnet package is required. Plsease set glmnet path
% accordingly.
glmnetpath = strcat(filepath,'glmnet_matlab/glmnet_matlab/');
addpath(glmnetpath)

kfold = 10;
par = 1;
numCores = 5;
[P,A] = deltanets(lfc,slope,grplist,kfold,par,numCores);

%% Rank genes based on prediction score
[rankMat,rankedG] = rankp(P);