function [P,A] = deltanets(lfc, slope, kfold, par, numCores)

%--------------------------------------------------------------------------
%DESCRIPTION:
%           The main function for DeltaNeTS for generating the protein scores 
%           for each drug treatment.
%
%INPUT ARGUMENTS:
%lfc             The matrix of log2FC data. Each row represents a gene and 
%                each column represents a sample.
%slope           The slope matrix from log2FC data. This matrix can be 
%                obtained using the function generateSlope(). If the data 
%                are not time-series, set slope to an empty matrix (i.e. 
%                slope=[]).
%kfold           The number of folds used in the k-fold cross validation.
%par             A Boolean variable TURE or FALSE indicating whether to use
%                parallel computing. The default is FALSE (no parallel 
%                computation).
%numCores        The number of CPU cores to be used for parallel computing.
%                This parameter is considered only if par is TRUE. The 
%                default is 4.
%
%OUTPUT ARGUMENTS:
% P              The matrix of perturbation impacts for each gene. Each
%                row corresponds to a gene following the same order as the 
%                one in the log2FC data, while each column corresponds to 
%                samples listed in tobject.
% A              The n*n matrix of the inferred GRN. The (i,j)-th 
%                element of the matrix corresponds to the coefficient of
%                regulaotry impact from gene j to gene i in the GRN. The 
%                rows and columns of the matrix correspond to genes
%                following the same order as in GList.
%--------------------------------------------------------------------------

if nargin<3 || isempty(kfold)
    kfold = 10;
end

if nargin < 4 || isempty(par)
    par = false;
end

if nargin < 5 || isempty(numCores)
    numCores = 4;
end

lfc = normr(lfc)*sqrt(size(lfc,2)-1);
[n,m] = size(lfc);

slope = normr(slope)*sqrt(size(slope,2)-1);
ms = size(slope,2);

%% DeltaNeTS-Lasso

BETA=zeros(n+m,n);

opts = [];
opts.intr = 0;
opts.alpha = 1;%%Lasso

if par
    poolobj = gcp('nocreate');
    delete(poolobj);
    parpool('local',numCores)
    parfor j=1:n
       fprintf('DeltaNeTS is running...(%4d/%d)\n',j,n);

       if ~isempty(slope)
           X = [lfc,slope];
           y = [lfc(j,:),slope(j,:)];
       else
           X = lfc;
           y = lfc(j,:);
       end

       Xin = [X',[eye(m);zeros(ms,m)]];
       opts2 = opts;
       opts2.exclude = j;
       result = cvglmnet(Xin,y',[],opts2,[],kfold);
       lambda_opt = find(result.lambda==result.lambda_min);
       beta = result.glmnet_fit.beta(:,lambda_opt);
       BETA(:,j) = beta';
    end
    poolobj = gcp('nocreate');
    delete(poolobj)
else
    for j=1:n
       fprintf('DeltaNeTS is running...(%4d/%d)\n',j,n);
       if ~isempty(slope)
           X = [lfc,slope];
           y = [lfc(j,:),slope(j,:)];
       else
           X = lfc;
           y = lfc(j,:);
       end

       Xin = [X',[eye(m);zeros(ms,m)]];
       opts2 = opts;
       opts2.exclude = j;
       result = cvglmnet(Xin,y',[],opts2,[],kfold);
       lambda_opt = find(result.lambda==result.lambda_min);
       beta = result.glmnet_fit.beta(:,lambda_opt);
       BETA(:,j) = beta';
    end
end

fprintf('P and A matrices are returning..\n')
A = BETA(1:n,:)';
P = BETA(n+1:end,:)';

end